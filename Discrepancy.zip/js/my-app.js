// Export selectors engine
var $$ = Dom7;
var iRecordCount = 0;

// Initialize your app
var myApp = new Framework7({
    modalTitle: 'eTime',
    animateNavBackIcon: false,
    preloadPreviousPage: false
});
var myswiper = myApp.swiper('.swiper-container', { pagination: '.swiper-pagination' });




// Add main View
var mainView = myApp.addView('.view-main', {
    // Enable dynamic Navbar
    dynamicNavbar: true,
});

//=== Urls
var BaseURLWeb = "http://voisysdbdev/SysDB.Api/api/DeviceManagement/"; // web dev
//var BaseURLApp = "https://sysdbapidev.voith.net/DeviceManagement/"; //mobile dev
var BaseURLApp = "https://sysdbapi.voith.net/DeviceManagement/"; //mobile prod

//https://sysdbapidev.voith.net/DeviceManagement/Getdevices?pattern={YourSearchPattern} 
//https://sysdbapidev.voith.net/DeviceManagement/GetDeviceTabInfos?deviceId={YourDeviceId}&tabId={YourTabId} 


var ENV = "WEB"; //Switch between mobile app and web app (Set for web:WEB and mobile:APP)

if (ENV != "APP" && (myApp.device.iphone || myApp.device.ipad || myApp.device.android)) {
    ENV = "APP";
}

if (ENV == "WEB") {
    BaseURLApp = BaseURLWeb;
}

/*
Local Store Keys
*/


function checkConnection() {
    var status = false;
    if (ENV === "APP") {
        var networkState = navigator.connection.type;

        var states = {};
        states[Connection.UNKNOWN] = 'Unknown connection';
        states[Connection.ETHERNET] = 'Ethernet connection';
        states[Connection.WIFI] = 'WiFi connection';
        states[Connection.CELL_2G] = 'Cell 2G connection';
        states[Connection.CELL_3G] = 'Cell 3G connection';
        states[Connection.CELL_4G] = 'Cell 4G connection';
        states[Connection.CELL] = 'Cell generic connection';
        states[Connection.NONE] = 'No network connection';

        //alert('Connection type: ' + states[networkState]);

        if (states[networkState].indexOf("WiFi") != -1 || states[networkState].indexOf("Cell") != -1)
            status = true;
        else
            status = false;
    } else {
        if (navigator.onLine)
            status = true;
        else
            status = false;
    }
    return status;
}

function GetDataAndRender(urlAddress, fnRenderData, Args, sLocalStoreKey) {
    myApp.showIndicator();
    if (checkConnection() === true) {
        $.ajax({
            url: urlAddress,
            type: "GET",
            dataType: 'json',
            success: function (result) {
                //alert("Ajax call : " + result);
                if (sLocalStoreKey != null)
                    localStorage.setItem(sLocalStoreKey, JSON.stringify(result));
                fnRenderData(result, Args);
                myApp.hideIndicator();
            },
            error: function (xhr, status, error) {
                myApp.hideIndicator();

                if (xhr.status === 401 || xhr.status === 0) {
                    myApp.alert("Authentication failed");
                }
                else if (checkConnection() === false) {
                    myApp.alert("Network is not available.");
                } else {
                    myApp.alert(error);
                }
            }
        });
    } else {
        myApp.hideIndicator();
        myApp.alert("Network is not available.");
    }
}

function getParmFromUrl(url, parm) {
    var re = new RegExp(".*[?&]" + parm + "=([^&]+)(&|$)");
    var match = url.match(re);
    return (match ? match[1] : "");
}

// Callbacks for specific pages when it initialized
/* ===== Modals Page events  ===== */
if (ENV == 'WEB') {
    $$('.visible-in-web').removeClass('visible-in-web');
    $$('.app-title').css('left', '10px');
    myApp.onPageInit('index', function () {
    }).trigger();
} else {
    myApp.onPageInit('index', function () {
    }).trigger();
}

// In page events:
$$(document).on('pageInit', function (e) {
    myApp.closeNotification(".notification-item");
    // Page Data contains all required information about loaded and initialized page 
    var page = e.detail.page;
    switch (page.name) {
   
        case "Attendance":
            CreateTableFromJSON();   
            break;
        case "Leave":
            RenderLeaveInfo();
            break;
        case "Discrepancy":
            RenderDiscrepancyInfo();
            break;
        case "index":
            RenderDiscrepancyInfo();
            break;
     
    }
})
    

//var swp =  myApp.swiper('.swiper-container', { speed: 400, spaceBetween: 200,});    
        
            

function CreateTableFromJSON() {
    var strtable1 = ""; 
    $.getJSON('./data/attendance.json', function (attendance_data) {

        var i;
       
        strtable1 += '<div class="swiper-slide"><div class="list-block accordion-list"><ul>';
        for (i = 0; i < 7; i++) {
            var a = parseFloat(attendance_data[i].WorkingHour);
            var badgetype = a >= 9 ? "badgeG" : "badgeR";
            strtable1 += '<li><div class="item-content"><div class="item-inner"><div class="item-title-row">';
            strtable1 += "<div class='item-title'>" + attendance_data[i].Date + "</div >";
            strtable1 += "<div class='item-after'>InTime:" + attendance_data[i].InTime + " OutTime:" + attendance_data[i].OutTime + "</div></div > ";
            strtable1 += "<div class='item-subtitle'>" + attendance_data[i].Status + "</div>";
            strtable1 += "<span class=" + badgetype + " >" + attendance_data[i].WorkingHour + "</span>";
            strtable1 += "</div></div></li>";
        }
        strtable1 += '</ul></div></div>';

        strtable1 += '<div class="swiper-slide"><div class="list-block accordion-list"><ul>';
        for (i = 0; i < 7; i++) {
            var a = parseFloat(attendance_data[i].WorkingHour);
            var badgetype = a >= 9 ? "badgeG" : "badgeR";
            strtable1 += '<li><div class="item-content"><div class="item-inner"><div class="item-title-row">';
            strtable1 += "<div class='item-title'>" + attendance_data[i].Date + "</div >";
            strtable1 += "<div class='item-after'>InTime:" + attendance_data[i].InTime + " OutTime:" + attendance_data[i].OutTime + "</div></div > ";
            strtable1 += "<div class='item-subtitle'>" + attendance_data[i].Status + "</div>";
            strtable1 += "<span class=" + badgetype + " >" + attendance_data[i].WorkingHour + "</span>";
            strtable1 += "</div></div></li>";
        }
        strtable1 += '</ul></div></div>';
        $("#wrap").html(strtable1);

    });   
    
}


function RenderDiscrepancyInfo() {
    var strtable = '';
    $.getJSON('./data/Discrepancy.json', function (attendance_data) {
        console.log(attendance_data);
        var i;

         for (i = 0; i < attendance_data.length; i++) {
            strtable += '<li><div class="item-content"><div class="item-inner"><div class="item-title-row">';
            strtable += "<div class='item-title'>" + attendance_data[i].Discrepancy + "</div>";
            strtable += "</div>";
            strtable += "</div></div></li> ";
             }
      
        $$("#ulDiscrepancyTabs").html(strtable);
    });
   


}
function RenderLeaveInfo() {
    var strHtml = '';

    $.getJSON('./data/Leave.json', function (attendance_data) {
        
        console.log(attendance_data);
        $$.each(attendance_data, function (i) {
            var obj = attendance_data[i];
            $$.each(obj["Leaves"], function (j) {
                strHtml += '<li class="accordion-item">';
                strHtml += ' <a href="#" class="item-content item-link">';
                strHtml += '<div class="item-inner">'
                strHtml += '<div class="item-title-row">'
                strHtml += '<div class="item-title">' + obj["Leaves"][j]["name"] + '</div>';
                strHtml += '<div class="item-after">Opening - ' + obj["Leaves"][j]["openingBalance"] + ' closing - ' + obj["Leaves"][j]["closingBalance"] + '</div>';
                strHtml += '</div>';
                strHtml += ' <div class="item-subtitle">Availd - ' + obj["Leaves"][j]["Availed"] + '</div>';
                strHtml += '</div></a>';
                $$.each(obj["Leaves"][j]["LeaveDetails"], function (k) {
                    var objIterate = obj["Leaves"][j]["LeaveDetails"][k];

                    strHtml += '<div class="accordion-item-content">';
                    strHtml += '<div class="list-block">';
                    strHtml += '<ul>';
                    strHtml += '<li>';
                    strHtml += '<div class="item-content">';
                    strHtml += '<div class="item-inner"><div class="item-title-row">';
                    strHtml += '<div class="item-subtitle">Frome date &nbsp; &nbsp; To date<br />' + objIterate["FromDate"] + '&nbsp; &nbsp;' + objIterate["ToDate"] + '</div>'

                    strHtml += '</div>';

                    strHtml += '<div class="item-subtitle">Quantity - ' + objIterate["Quantity"] + '</div>'
                    strHtml += '</div>';
                    strHtml += '</div>';
                    strHtml += '</li>';
                    strHtml += '</ul>';
                    strHtml += '</div>';
                    strHtml += '</div>';

                });

                strHtml += '</li>'
            });
        });
        $$("#ulLeaveTabs").html(strHtml);
    });
}

function OpenHomePage() {
    $$('#discreancy').removeClass('active');
    $$('#leave').removeClass('active');
    $$('#attendence').removeClass('active');
    $$('#home').addClass('active');
    mainView.router.loadPage("index.html");
    
}

function OpenAttendencePage() {
    $$('#discreancy').removeClass('active');
    $$('#leave').removeClass('active');
    $$('#attendence').addClass('active');
    $$('#home').removeClass('active');
    mainView.router.loadPage("Attendence.html");
 
}
function OpenLeavePage() {
    $$('#discreancy').removeClass('active');
    $$('#leave').addClass('active');
    $$('#attendence').removeClass('active');
    $$('#home').removeClass('active');
    mainView.router.loadPage("Leave.html");
   
}
function OpenDiscrepancyPage() {
    $$('#discreancy').addClass('active');
    $$('#leave').removeClass('active');
    $$('#attendence').removeClass('active');
    $$('#home').removeClass('active');
    mainView.router.loadPage("Discrepancy.html");
}