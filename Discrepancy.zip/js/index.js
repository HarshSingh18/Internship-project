var app = {
    startCameraAbove: function () {
        CameraPreview.startCamera({ x: 50, y: 50, width: 300, height: 300, toBack: false, previewDrag: true, tapPhoto: true });
    },
    
    stopCamera: function () {
        CameraPreview.stopCamera();
    },

    takePicture: function () {
        CameraPreview.takePicture(function (imgData) {
            document.getElementById('originalPicture').src = 'data:image/jpeg;base64,' + imgData;
        });
    },

    switchCamera: function () {
        CameraPreview.switchCamera();
    },
    
    onDeviceReady: function () {
        //alert("deviceready");

        var success = function (message) {
            alert("Success:" + message);
        }

        var failure = function (error) {
            alert("Error:" + error);
        }

        //clientCertificate.registerAuthenticationCertificate("zzHDHSysDB_MobileApp.p12", "483268526080", success, failure);
        clientCertificate.register("zzHDHSysDB_MobileApp.p12", "483268526080", success, failure);
    },

    init: function () {
        document.getElementById('startCameraAboveButton').addEventListener('click', this.startCameraAbove, false);
     

        document.getElementById('stopCameraButton').addEventListener('click', this.stopCamera, false);
        document.getElementById('switchCameraButton').addEventListener('click', this.switchCamera, false);
        document.getElementById('takePictureButton').addEventListener('click', this.takePicture, false);

        window.smallPreview = false;
    }
};

document.addEventListener('deviceready', function () {
    app.init();
}, false);
